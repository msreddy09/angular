import { Component, OnInit } from '@angular/core';
import { BonusService } from './bonus.service'
import { ExportService } from '../_services/export.service';

@Component({
  selector: 'app-bonus',
  templateUrl: './bonus.component.html',
  styleUrls: ['./bonus.component.css']
})
export class BonusComponent implements OnInit {
  errorMessage: string;
  bonus_total_pool_amt: number = 2000000;
  bonus_total_pool_amt_allocated: number = 2000000;
  exchange_rate: number = 0.17472020;
  constructor(private BonusService: BonusService, private exportService: ExportService) {

  }
  bonusData: [] = [];
  rolesData: [] = [];
  roleCodes = [];
  menuCodes = [];
  newRoleAndMenuArray = [];
  ngOnInit() {
    this.BonusService.getBonusData().subscribe(
      data => {
        for (let d in data.data) {
          var changeRate = ((parseInt(data.data[d].currentYearTotalPool) / parseInt(data.data[d].currentYearBaseline)) * 100 - 100).toFixed(2);
          data.data[d].changeFromBaseline = changeRate
        }
        this.bonusData = data.data
      },
      error => this.errorMessage = <any>error
    )

    this.BonusService.getRolesData().subscribe(
      data => {
        this.rolesData = data.data
        this.getMenuAndRoleCodes(this.rolesData);
        this.createRoleAndMenuDataForTable(this.rolesData);
        console.log(this.newRoleAndMenuArray);
      },
      error => this.errorMessage = <any>error
    )

  }

  createRoleAndMenuDataForTable(objArray) {
    for (var i = 0; i < this.roleCodes.length; i++) {
      var ob = { "roleCode": this.roleCodes[i] };
      for (var obj of objArray) {
        if (this.roleCodes[i] === obj.roleCode) {
          for (var k in this.menuCodes) {
            if (obj.menuCode === this.menuCodes[k]) {
              ob[this.menuCodes[k]] = obj.checked;
            }
          }
        }
      }
      this.newRoleAndMenuArray.push(ob);
    }
  }

  getMenuAndRoleCodes(objArray: any) {
    for (let obj of objArray) {
      if (this.roleCodes.indexOf(obj.roleCode) === -1) {
        this.roleCodes.push(obj.roleCode);
      }
      if (this.menuCodes.indexOf(obj.menuCode) === -1) {
        this.menuCodes.push(obj.menuCode);
      }
    }
  }
  export() {
    this.exportService.exportExcel(this.bonusData, 'Bonus Allocation ');
  }

  save() {
    alert('Save called!');
  }

  submit() {
    alert('Submit called!');
  }

  saveRoles() {
    var newArrayObj = [];
    for (var i = 0; i < this.newRoleAndMenuArray.length; i++) {
      var obj = {};
      var roleCodeValue = ''
      for (var k in this.newRoleAndMenuArray[i]) {
        if (k === 'roleCode') {
          roleCodeValue = this.newRoleAndMenuArray[i][k]
        } else {
          let obj = { "roleCode": roleCodeValue, "menuCode": k, checked: this.newRoleAndMenuArray[i][k] }
          newArrayObj.push(obj);
        }
      }
    }
    console.log(newArrayObj);
  }

}
