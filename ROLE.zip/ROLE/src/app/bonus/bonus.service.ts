import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { catchError, tap, map } from 'rxjs/operators';
import { throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class BonusService {
  private bonusServiceURL: string = 'api/bonusdata.json';
  private rolesServiceURL: string = 'api/rolesdata.json';

  constructor(private http: HttpClient) {

  }
  getBonusData(): any {
    return this.http.get(this.bonusServiceURL).pipe(
      tap(data => console.log('Products data recieved'))
    )
  }

  getRolesData(): any {
    return this.http.get(this.rolesServiceURL).pipe(
      tap(data => console.log('roles data recieved'))
    )
  }  
}